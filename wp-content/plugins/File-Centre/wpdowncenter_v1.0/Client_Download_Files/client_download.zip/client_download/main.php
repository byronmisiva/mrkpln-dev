<?php
/**
Plugin Name: Wordpress Download Centre
Description: The Wordpress Download Centre plguin allow you to upload files for clients / users, which can be accessed using access details created through the wordpress control panel.
Author: James Willson
Version: 1.0
Author URI: mailto:info@rawmedia.net
*/

session_start();


$client_path['url']=WP_PLUGIN_URL.'/client_download/';
$client_path['abs']=WP_PLUGIN_DIR.'/client_download/';
$client_path['upload_abs']=WP_CONTENT_DIR.'/client_download/';
$client_path['upload_url']=WP_CONTENT_URL.'/client_download/';


$table_client_info=$wpdb->prefix."clients_info";
$table_client_files=$wpdb->prefix."clients_files";


add_action('admin_menu','client_menu');


function client_menu()
{
	add_menu_page(__('Client Center'), 'Client Center',4,'client/manage', 'client_manager');
	
		add_submenu_page('client/manage','Manage Client','Manage Client',4,'client/manage', 'client_manager');
		
		add_submenu_page('client/manage','Add Client','Add Client',4,'client/add_client', 'client_add');	
		
		add_submenu_page('client/manage','Add Files','Add Files',4,'client/add_file', 'client_add_files');	
}


function client_manager()
{
	global $wpdb,$client_path;
	include('manage_client.php');
}

function client_add()
{
	global $wpdb,$client_path;
	include('add_client.php');
}

function client_add_files()
{
	global $wpdb,$client_path;
	include('add_files.php');
}



function show_client_message($msg,$type='updated')
{
	echo '<div class="'.$type.' fade">'.$msg.'</div>';
}




function is_client_exist($cname)
{
	global $wpdb,$table_client_info;
	
	//$sql="SELECT id FROM $table_client_info WHERE name='$cname' AND password='$cpassword'";
	$sql="SELECT id FROM $table_client_info WHERE name='$cname' LIMIT 1";
	$cid=$wpdb->get_var($sql);
	return $cid;
	
}





function add_new_file($client_id,$name,$description,$file_path,$size)
{
	global $wpdb,$table_client_info,$table_client_files;
	
	
		$sql="INSERT INTO $table_client_files SET client_id='$client_id', name='$name', description='$description',file_path='$file_path',size='$size'";
		if($wpdb->query($sql))
		{
			return true;
		}
	
}

function do_client_login($cname,$cpassword)
{
	global $wpdb,$table_client_info;
	
	$sql="SELECT * FROM $table_client_info WHERE name='$cname' AND password='$cpassword'";
	$results=$wpdb->get_results($sql);
	if($results)
	return $results[0];
	else
	return false;
	
}




function get_client_files($client_id)
{
	global $wpdb,$table_client_info,$table_client_files;
	
	
		$sql="SELECT * FROM  $table_client_files WHERE client_id='$client_id'";
		$files=$wpdb->get_results($sql);
		
		if($files)
		{
			return $files;
		}else
		return false;
	
}

function delete_file($file_id)
{
	global $wpdb,$table_client_info,$table_client_files;
	
	
		$sql="DELETE FROM  $table_client_files WHERE id='$file_id' LIMIT 1";
		$files=$wpdb->query($sql);
		
		if($files)
		{
			return true;
		}else
		return false;
	
}



function add_new_client($cname,$cpassword)
{
	global $wpdb,$table_client_info;
	
	if($cname=="" || $cpassword=="")
	{
		return false;
	}else
	{
		$sql="INSERT INTO $table_client_info SET name='$cname', password='$cpassword',status='active'";
		if($wpdb->query($sql))
		{
			return true;
		}
	}
	
}



function get_all_clients()
{
	global $wpdb,$table_client_info;
	
	
		$sql="SELECT * FROM  $table_client_info ORDER BY name";
		$results=$wpdb->get_results($sql);
		if($results)
		return $results;
		else
		return false;
	
}

function get_client_byid($client_id)
{
	global $wpdb,$table_client_info;
	
	
		$sql="SELECT * FROM  $table_client_info WHERE id='$client_id' LIMIT 1";
		$results=$wpdb->get_results($sql);
		if($results)
		return $results[0];
		else
		return false;
	
}

function delete_client_byid($client_id)
{
	global $wpdb,$table_client_info;
	
	
		$sql="DELETE FROM  $table_client_info WHERE id='$client_id' LIMIT 1";
		$results=$wpdb->query($sql);
		if($results)
		return true;
		else
		return false;
	
}

//================

add_action('the_content','get_client_download_area');

function get_client_download_area($content)
{
	if(strpos($content,'[[client_download_page]]')==true)
	{
		return str_replace('[[client_download_page]]',client_download_files(),$content);
	}else
	return $content;

}


function client_download_files()
{
	global $client_path;
	include('client_form.php');
	
	
}

/// hook
register_activation_hook(__FILE__,'client_install');
register_deactivation_hook(__FILE__,'client_deactivate');


function client_install()
{
	
	global $wpdb;
	
	$table_client_info=$wpdb->prefix."clients_info";
	$table_client_files=$wpdb->prefix."clients_files";
	
	$sql='CREATE TABLE IF NOT EXISTS `'.$table_client_info.'` 
		(
		  `id` bigint(20) NOT NULL AUTO_INCREMENT,
		  `name` varchar(255) NOT NULL,
		  `password` varchar(255) NOT NULL,
		  `status` varchar(10) NOT NULL,
		  PRIMARY KEY (`id`)
		) ;';
	
	$sql2='CREATE TABLE IF NOT EXISTS `'.$table_client_files.'` 
		 (
		  `id` bigint(20) NOT NULL AUTO_INCREMENT,
		  `client_id` bigint(20) NOT NULL,
		  `name` varchar(255) NOT NULL,
		  `description` text NOT NULL,
		  `size` varchar(10) NOT NULL,
		  `file_path` varchar(500) NOT NULL,
		  PRIMARY KEY (`id`)
			);';
	
	
	$file_path=ABSPATH . 'wp-admin/includes/upgrade.php';
	require_once($file_path);
    dbDelta($sql);
	 dbDelta($sql2);
}

function client_deactivate()
{
	
	global $wpdb;
	
	$table_client_info=$wpdb->prefix."clients_info";
	$table_client_files=$wpdb->prefix."clients_files";
	
	$sql='DROP TABLE IF EXISTS `'.$table_client_info.'`';
	
	$sql2='DROP TABLE IF EXISTS `'.$table_client_files.'`';
	
	$wpdb->query($sql);
	$wpdb->query($sql2);
	
	

}





?>