<div class="wrap">
<h2>Add Client </h2>
<?php

//show_client_message('This is client add section');

if(isset($_POST['btnaddclient']))
{
	if(!is_client_exist(trim($_POST['cname'])))
	{
		
		$added=add_new_client(trim($_POST['cname']),trim($_POST['cpassword']));
	
		if(!$added)
		{
			show_client_message('Any Field Should not be Empty !','error');
		}else
		{
			$main_page=get_option('siteurl')."/wp-admin/admin.php?page=client/manage";
			show_client_message('Client Successfully Added');
			print('
			<script language="javasript" type="text/javascript">
			window.location="'.$main_page.'";
			</script>
			');
		}
	}else
	{
		show_client_message('Username Already Exists !','error');
	}

}
?>

<form name="clientadd" method="post" action="">
<table border="0" class="widefat" style="width:400px;">
  <thead>
  <tr>
    <th>User Name</th>
    <th>Password / Access Code</th>
  </tr>
  </thead>
  
  <tbody>
   <tr>
    <td><input name="cname" type="text" id="cname"></td>
    <td><input name="cpassword" type="text" id="cpassword"></td>
  </tr>
   <tr>
    <td colspan="2"><input name="btnaddclient" type="submit" id="btnaddclient" value="Add New Client" class="button-primary"></td>
    </tr>
  </tbody>
</table>
</form>



</div>