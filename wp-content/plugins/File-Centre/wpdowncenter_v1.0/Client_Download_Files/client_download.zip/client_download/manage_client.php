<div class="wrap">

<h2>Manage clients</h2>

<div style="width:600px;">

<?php

if($_GET['action']=='delete')
{
	if(delete_client_byid($_GET['client_id']))
	{
		show_client_message('Client Deleted Successfully');
	}
}

?>


<table border="0" class="widefat">
 <thead>
  <tr>
    <th>ID#</th>
    <th>Username</th>
    <th>Access Code</th>
    <th>&nbsp;</th>
  </tr>
  </thead>
  
  <tbody>
  
  <?php
  
 $clients= get_all_clients();
 
 if($clients)
 {
 	foreach($clients as $client)
	{
		?>
		
		<tr>
		<td><?php echo $client->id?></td>
		<td><?php echo $client->name?></td>
		<td><?php echo $client->password?></td>
		<td><a href="admin.php?page=client/manage&action=showfile&client_id=<?php echo $client->id?>" >Show files</a> |  <a href="admin.php?page=client/manage&action=delete&client_id=<?php echo $client->id?>" onClick="javascript: return confirm('Are your sure to delete ?')">Delete Client</a></td>
	  </tr>
		
		<?php
	}
 }
  
  ?>
  <tr>
		<td colspan="4">&nbsp;</td>
		</tr>
 <tr>
		<td></td>
		<td><a href="admin.php?page=client/add_client" class="button-primary">Add Client</a></td>
		<td>
		<a href="admin.php?page=client/add_file" class="button-primary">Add Files</a></td>
		<td></td>
	  </tr>
  </tbody>
</table>

</div>

<?php
if($_GET['fileaction']=='delete')
{
	if(delete_file($_GET['file_id']))
	{
		show_client_message('File Deleted Successfully');
	}
}

?>



<?php

if($_GET['action']=='showfile')
{

$client=get_client_byid($_GET['client_id']);
$files=get_client_files($_GET['client_id']);


?>
<h2>File Listing for <?php echo $client->name?></h2>

<div style="width:600px;">


<table border="0" class="widefat">
<thead>
  <tr>
    <th>File name</th>
    <th>Description</th>
    <th>Size</th>
    <th>&nbsp;</th>
  </tr>
  </thead>
  <tbody>
  <?php
  if($files)
  {
	  foreach($files as $file)
	  {
		  ?>
		  <tr>
			<td><?php echo $file->name?></td>
			<td><?php echo $file->description?></td>
			<td><?php echo  number_format((($file->size)/1024), 2, '.','');?> KB</td>
			<td><a href="admin.php?page=client/manage&action=showfile&client_id=<?php echo $file->client_id?>&fileaction=delete&file_id=<?php echo $file->id?>" onClick="javascript: return confirm('Are your sure to delete this file ?')">Delete File</a>&nbsp;</td>
		  </tr>
		  <?php
	  } 
	  
  } //end if
  else
  {
  ?>
  <tr>
			<td colspan="4">None</td>
		  </tr>
  
  <?php
  }
  
  ?>
  </tbody>
</table>

</div>



<?php
}

?>



</div>