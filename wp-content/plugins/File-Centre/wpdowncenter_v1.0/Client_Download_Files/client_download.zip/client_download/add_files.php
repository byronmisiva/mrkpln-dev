<div class="wrap">
<h2>Add Files</h2>

<?php

if(isset($_POST['filename']) && $_POST['filename']!="")
{
	extract($_POST);
	
	
	$file_details=unserialize(stripslashes($file_details));
	
	if(!empty($file_details))
	{
		if($file_details['client_file']['name']!="")
		{
			$name=$file_details['client_file']['name'];
			$size=$file_details['client_file']['size'];
			$file_path=WP_CONTENT_URL.'/clients_file/'.$name;
			
				if(add_new_file($user,$name,$description,$file_path,$size))
				{
					show_client_message('File added Successfully');
				}
		}else
		{
			show_client_message('Unable to add this file','error');
		}
	}
	else
		{
			show_client_message('Unable to add this file','error');
		}
	
	
}


?>

<script type="text/javascript" src="<?php echo $client_path['url']?>swfupload/swfupload.js"></script>
<script type="text/javascript" src="<?php echo $client_path['url']?>swfupload/js/fileprogress.js"></script>
<script type="text/javascript" src="<?php echo $client_path['url']?>swfupload/js/handlers.js"></script>
<link rel="stylesheet" href="<?php echo $client_path['url']?>swfupload/default.css" media="all" />
<script type="text/javascript">
		var swfu;

		window.onload = function () {
			swfu = new SWFUpload({
				// Backend settings
				upload_url: "<?php echo $client_path['url']?>upload.php",
				file_post_name: "client_file",

				// Flash file settings
				file_size_limit : "100 MB",
				file_types : "*.*",			// or you could use something like: "*.doc;*.wpd;*.pdf",
				file_types_description : "All Files",
				file_upload_limit : "0",
				file_queue_limit : "1",

				// Event handler settings
				swfupload_loaded_handler : swfUploadLoaded,
				
				file_dialog_start_handler: fileDialogStart,
				file_queued_handler : fileQueued,
				file_queue_error_handler : fileQueueError,
				file_dialog_complete_handler : fileDialogComplete,
				
				//upload_start_handler : uploadStart,	// I could do some client/JavaScript validation here, but I don't need to.
				upload_progress_handler : uploadProgress,
				upload_error_handler : uploadError,
				upload_success_handler : uploadSuccess,
				upload_complete_handler : uploadComplete,

				// Button Settings
				button_image_url : "<?php echo $client_path['url']?>swfupload/button.png",
				button_placeholder_id : "spanButtonPlaceholder",
				button_width: 61,
				button_height: 22,
				
				// Flash Settings
				flash_url : "<?php echo $client_path['url']?>swfupload/swfupload.swf",

				custom_settings : {
					progress_target : "fsUploadProgress",
					upload_successful : false
				},
				
				// Debug settings
				debug: false
			});

		};
	</script>

<form action="" method="post" enctype="multipart/form-data">

<table border="0" class="widefat" style="width:500px;">
  <tr>
    <th>Select User </th>
    <td>
	<?php 
	
	$clients=get_all_clients();
	if($clients)
	{
	$str_client="";
	
		foreach($clients as $client)
		{
			$str_client .='<option value="'.$client->id.'">'.$client->name.' ( '.$client->id.' )'.'</option>';
		}
	}
	?>
	
	<select name="user" id="user">
	<?php echo $str_client?>
    </select>
    </td>
  </tr>
  <tr>
    <th>Select File to upload </th>
    <td><input name="filename" type="text" id="filename"><span id="spanButtonPlaceholder"></span>(Max 100 MB) 
	<br/>
	<div id="fsUploadProgress"></div>
	
	</td>
  </tr>
  <tr>
    <th>Description</th>
    <td><textarea name="description" cols="30" rows="3" id="description"></textarea></td>
  </tr>
  <tr>
    <th>&nbsp;</th>
    <td>
	
	<input type="hidden" name="file_details" id="file_details" />
	<input name="btnaddfile" type="submit" id="btnaddfile" value="Add New File" class="button-primary"></td>
  </tr>
</table>




</form>






</div>