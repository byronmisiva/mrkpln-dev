<?php

$file_path_arr=explode('plugins',__FILE__);
$file_path=$file_path_arr[0].'clients_file';
if(!file_exists($file_path))
{
	mkdir($file_path,0777);
	fopen($file_path."/index.html","w");
}



	if (isset($_FILES["client_file"]) && is_uploaded_file($_FILES["client_file"]["tmp_name"]) && $_FILES["client_file"]["error"] == 0) 
	{
		if(move_uploaded_file($_FILES["client_file"]["tmp_name"],$file_path."/".$_FILES["client_file"]["name"]))
		{
			echo serialize($_FILES);
		}
		
	}
	
	
?>