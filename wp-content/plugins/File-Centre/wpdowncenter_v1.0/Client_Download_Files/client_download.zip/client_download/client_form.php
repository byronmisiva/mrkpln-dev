<link rel="stylesheet" href="<?php echo $client_path['url']?>style.css" media="all" />
<?php

if($_GET['action']=='logout')
{
	$_SESSION['is_client_logged_in']=NULL;
}

if(isset($_POST['wp-submit']))
{
	extract($_POST);
	$client=do_client_login($username,$password);
	if($client)
	{
		$_SESSION['client_name']=$client->name;
		$_SESSION['client_id']=$client->id;
		$_SESSION['is_client_logged_in']='yes';
	
	}else
	{
	 echo '<div style="padding:5px;border:1px solid red;">Username or Access code Not Correct</div>';
	}
}

if($_SESSION['is_client_logged_in']!='yes' || $_SESSION['is_client_logged_in']=="")
{

?>

<form name="clientform" id="clientform" action="" method="post">
	<p>
		<label>Username<br />
		<input type="text" name="username" id="username" class="input" value="" size="20" tabindex="10" /></label>
	</p>
	<p>
		<label>Password<br />
		<input type="password" name="password" id="password" class="input" value="" size="20" tabindex="20" /></label>

	</p>
	<p class="submit">
		<input type="submit" name="wp-submit" id="wp-submit" value="Log In" tabindex="100" />
	</p>
</form>
<?php

} // end login form




if($_SESSION['is_client_logged_in']=='yes')
{
$files=get_client_files($_SESSION['client_id']);
?>

<div id="file_download">


<table border="0" width="100%">
  <tr>
    <td>Welcome <?php echo $_SESSION['client_name']?> </td>
    <td class="last">
	<?php
	if(strpos($_SERVER['REQUEST_URI'],'?')!==false)
	{
	?>
	<a href="<?php echo $_SERVER['REQUEST_URI']?>&action=logout">Logout</a>
	<?php }else{?>
	<a href="<?php echo $_SERVER['REQUEST_URI']?>?action=logout">Logout</a>
	<?php }?>
	</td>
  </tr>
</table>


<?php

if($files)
{
$ii=1;
?>
<table border="0" width="100%">
<tr>
    <th>SI#</th>
    <th>File Name</th>
    <th>Description</th>
	<th>Size</th>
    <th class="last">Download Link</th>
  </tr>
<?php
foreach($files as $file)
{
?>
 <tr <?php echo ($ii%2==0)?'class="odd"':'class="even"';?>>
    <td ><?php echo $ii++?>#</td>
    <td><?php echo $file->name?>  </td>
    <td><?php echo $file->description?>  </td>
	<td><?php echo  number_format((($file->size)/1024), 2, '.','');?> KB </td>
    <td class="last"><a href="<?php echo $file->file_path?>" class="download_link" target="_blank">DOWNLOAD</a></td>
  </tr>
  
<?php
} // end foreach
echo '</table>';
}else
{
	 echo '<div style="padding:5px;border:1px solid red;">You have no File to Download</div>';
}

?>
 

</div>


<?php

} // end file download
 ?>