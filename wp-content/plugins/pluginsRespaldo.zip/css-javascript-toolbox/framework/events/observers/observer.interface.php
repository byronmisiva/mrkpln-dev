<?php
/**
* 
*/

/**
* 
*/
interface CJTIObserver {
	
	/**
	* put your comment there...
	* 
	* @param mixed $name
	*/
	public function getFilter($name);
	
	/**
	* put your comment there...
	* 
	*/
	public function trigger();
	
} // End interface.