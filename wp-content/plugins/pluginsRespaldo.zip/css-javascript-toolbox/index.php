<?php
// index.php just to prevent indexing of plugin folder