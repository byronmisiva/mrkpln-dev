<?php
/**
* 
*/

/**
* 
*/
class CJT_Models_Package_Xml_Definition_Package_Package_Block_Files_File
extends CJT_Models_Package_Xml_Definition_Frag_Frag_Block_Files_File {} // End class