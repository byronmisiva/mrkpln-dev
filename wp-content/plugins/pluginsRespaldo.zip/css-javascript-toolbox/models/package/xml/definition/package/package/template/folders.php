<?php
/**
* 
*/

/**
* 
*/
class CJT_Models_Package_Xml_Definition_Package_Package_Template_Folders
extends CJT_Models_Package_Xml_Definition_Frag_Frag_Template_Folders {} // End class